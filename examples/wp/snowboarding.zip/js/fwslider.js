var _0x69b9 = [
	"\x69\x6E\x69\x74",
	"\x62\x69\x6E\x64\x43\x6F\x6E\x74\x72\x6F\x6C\x73", 
	"\x68\x65\x69\x67\x68\x74", 
	"\x23\x66\x77\x73\x6C\x69\x64\x65\x72\x20\x2E\x73\x6C\x69\x64\x65", 
	"\x63\x73\x73", "\x23\x66\x77\x73\x6C\x69\x64\x65\x72", 
	"\x70\x6F\x73\x69\x74\x69\x6F\x6E", 
	"\x72\x65\x73\x69\x7A\x65", 
	"\x23\x66\x77\x73\x6C\x69\x64\x65\x72\x20\x2E\x73\x6C\x69\x64\x65\x4E\x65\x78\x74", 
	"\x23\x66\x77\x73\x6C\x69\x64\x65\x72\x20\x2E\x73\x6C\x69\x64\x65\x50\x72\x65\x76\x2C\x20\x23\x66\x77\x73\x6C\x69\x64\x65\x72\x20\x2E\x73\x6C\x69\x64\x65\x4E\x65\x78\x74", 
	"\x23\x66\x77\x73\x6C\x69\x64\x65\x72\x20\x2E\x73\x6C\x69\x64\x65\x50\x72\x65\x76", 
	"\x6D\x6F\x75\x73\x65\x6F\x76\x65\x72", 
	"\x65\x61\x73\x65\x4F\x75\x74\x43\x75\x62\x69\x63", 
	"\x61\x6E\x69\x6D\x61\x74\x65", 
	"\x6F\x6E", 
	"\x6D\x6F\x75\x73\x65\x6F\x75\x74", 
	"\x63\x6C\x69\x63\x6B", 
	"\x3A\x61\x6E\x69\x6D\x61\x74\x65\x64", "\x69\x73", "\x6C\x65\x6E\x67\x74\x68", 
	"\x23\x66\x77\x73\x6C\x69\x64\x65\x72\x20\x2E\x73\x6C\x69\x64\x65\x3A\x65\x71\x28", "\x63\x73", "\x29", "\x73\x74\x6F\x70", 
	"\x23\x66\x77\x73\x6C\x69\x64\x65\x72\x20\x2E\x74\x69\x6D\x65\x72\x73\x20\x2E\x74\x69\x6D\x65\x72\x20\x2E\x70\x72\x6F\x67\x72\x65\x73\x73", "\x31\x30\x30\x25", 
	"\x64\x75\x72\x61\x74\x69\x6F\x6E", "\x30\x25", 
	"\x23\x66\x77\x73\x6C\x69\x64\x65\x72\x20\x2E\x74\x69\x6D\x65\x72\x73\x20\x2E\x74\x69\x6D\x65\x72\x3A\x6C\x61\x73\x74\x20\x2E\x70\x72\x6F\x67\x72\x65\x73\x73", 
	"\x23\x66\x77\x73\x6C\x69\x64\x65\x72\x20\x2E\x74\x69\x6D\x65\x72\x73\x20\x2E\x74\x69\x6D\x65\x72\x3A\x6C\x74\x28", "\x29\x20\x2E\x70\x72\x6F\x67\x72\x65\x73\x73", 
	"\x73\x68\x6F\x77", "\x69\x6E\x64\x65\x78", "\x23\x66\x77\x73\x6C\x69\x64\x65\x72\x20\x2E\x74\x69\x6D\x65\x72\x73\x20\x2E\x74\x69\x6D\x65\x72\x3A\x67\x74\x28", 
	"\x23\x66\x77\x73\x6C\x69\x64\x65\x72\x20\x2E\x74\x69\x6D\x65\x72\x73\x20\x2E\x74\x69\x6D\x65\x72\x3A\x65\x71\x28", "\x23\x66\x77\x73\x6C\x69\x64\x65\x72\x20\x2E\x74\x69\x6D\x65\x72\x73",
	"\x61\x70\x70\x65\x6E\x64\x54\x6F", 
	"\x3C\x64\x69\x76\x20\x63\x6C\x61\x73\x73\x3D\x22\x74\x69\x6D\x65\x72\x22\x3E\x3C\x64\x69\x76\x20\x63\x6C\x61\x73\x73\x3D\x22\x70\x72\x6F\x67\x72\x65\x73\x73\x22\x3E\x3C\x2F\x64\x69\x76\x3E\x3C\x2F\x64\x69\x76\x3E", "\x23\x66\x77\x73\x6C\x69\x64\x65\x72\x20\x2E\x74\x69\x6D\x65\x72\x73\x20\x2E\x74\x69\x6D\x65\x72", 
	"\x73\x77\x69\x6E\x67", "\x66\x61\x64\x65\x49\x6E", "\x23\x66\x77\x73\x6C\x69\x64\x65\x72\x20\x2E\x73\x6C\x69\x64\x65\x3A\x66\x69\x72\x73\x74\x20\x69\x6D\x67", 
	"\x65\x61\x73\x65\x49\x6E\x4F\x75\x74\x45\x78\x70\x6F", "\x73\x68\x6F\x77\x54\x65\x78\x74", "\x72\x75\x6E", "\x66\x6F\x63\x75\x73", "\x68\x69\x64\x65\x54\x65\x78\x74", 
	"\x68\x69\x64\x65", "\x23\x66\x77\x73\x6C\x69\x64\x65\x72\x20\x2E\x73\x6C\x69\x64\x65\x3A\x6C\x74\x28", 
	"\x29\x2C\x20\x23\x66\x77\x73\x6C\x69\x64\x65\x72\x20\x2E\x73\x6C\x69\x64\x65\x3A\x67\x74\x28", "\x29\x20\x2E\x74\x69\x74\x6C\x65", 
	"\x29\x20\x2E\x64\x65\x73\x63\x72\x69\x70\x74\x69\x6F\x6E", "\x29\x20\x2E\x72\x65\x61\x64\x6D\x6F\x72\x65", 
	"\x23\x66\x77\x73\x6C\x69\x64\x65\x72\x20\x2E\x73\x6C\x69\x64\x65\x20\x2E\x74\x69\x74\x6C\x65", 
	"\x23\x66\x77\x73\x6C\x69\x64\x65\x72\x20\x2E\x73\x6C\x69\x64\x65\x20\x2E\x64\x65\x73\x63\x72\x69\x70\x74\x69\x6F\x6E", 
	"\x23\x66\x77\x73\x6C\x69\x64\x65\x72\x20\x2E\x73\x6C\x69\x64\x65\x20\x2E\x72\x65\x61\x64\x6D\x6F\x72\x65", "\x70\x61\x75\x73\x65", "\x77\x69\x64\x74\x68", 
	"\x23\x66\x77\x73\x6C\x69\x64\x65\x72\x20\x2E\x74\x69\x6D\x65\x72\x3A\x65\x71\x28", "\x6C\x69\x6E\x65\x61\x72", "\x74\x72\x69\x67\x67\x65\x72", 
	"\x23\x66\x77\x73\x6C\x69\x64\x65\x72\x20\x2E\x74\x69\x6D\x65\x72\x20\x2E\x70\x72\x6F\x67\x72\x65\x73\x73", 
	"\x23\x66\x77\x73\x6C\x69\x64\x65\x72\x20\x2E\x73\x6C\x69\x64\x65\x5F\x63\x6F\x6E\x74\x65\x6E\x74",
	"\x6D\x6F\x75\x73\x65\x6C\x65\x61\x76\x65", "\x6C\x6F\x61\x64"
];

(function($){
function mainSlider() {
    var _0xe8e3x2 = {
        cs: 0,
        pause: 5000,
        duration: 750
    };
    this[_0x69b9[0]] = function() {
        _0xe8e3x5[_0x69b9[0]]();
        _0xe8e3x3[_0x69b9[1]]();
        _0xe8e3x4[_0x69b9[1]]();
    };
    var _0xe8e3x3 = {
        resize: function() {
            $(_0x69b9[5])[_0x69b9[4]]({
                height: $(_0x69b9[3])[_0x69b9[2]]()
            });
            _0xe8e3x4[_0x69b9[6]]();
        },
        bindControls: function() {
            $(window)[_0x69b9[7]](function() {
                _0xe8e3x3[_0x69b9[7]]();
            });
        }
    };
    var _0xe8e3x4 = {
        position: function() {
            $(_0x69b9[9])[_0x69b9[4]]({
                top: $(_0x69b9[5])[_0x69b9[2]]() / 2 - $(_0x69b9[8])[_0x69b9[2]]() / 2
            });
            $(_0x69b9[10])[_0x69b9[4]]({
                left: 0
            });
            $(_0x69b9[8])[_0x69b9[4]]({
                right: 0
            });
        },
        bindControls: function() {
            $(_0x69b9[9])[_0x69b9[14]](_0x69b9[11], function() {
                $(this)[_0x69b9[13]]({
                    opacity: 1
                }, {
                    queue: false,
                    duration: 1000,
                    easing: _0x69b9[12]
                });
            });
            $(_0x69b9[9])[_0x69b9[14]](_0x69b9[15], function() {
                $(this)[_0x69b9[13]]({
                    opacity: 0.5
                }, {
                    queue: false,
                    duration: 1000,
                    easing: _0x69b9[12]
                });
            });
            $(_0x69b9[8])[_0x69b9[14]](_0x69b9[16], function() {
                if ($(_0x69b9[3])[_0x69b9[18]](_0x69b9[17])) {
                    return;
                };
                if ($(_0x69b9[20] + (_0xe8e3x2[_0x69b9[21]] + 1) + _0x69b9[22])[_0x69b9[19]] <= 0) {
                    _0xe8e3x2[_0x69b9[21]] = 0;
                    $(_0x69b9[24])[_0x69b9[23]]();
                    $(_0x69b9[28])[_0x69b9[13]]({
                        width: _0x69b9[25]
                    }, {
                        queue: false,
                        duration: _0xe8e3x2[_0x69b9[26]],
                        easing: _0x69b9[12],
                        complete: function() {
                            $(_0x69b9[24])[_0x69b9[4]]({
                                width: _0x69b9[27]
                            });
                        }
                    });
                } else {
                    _0xe8e3x2[_0x69b9[21]]++;
                    $(_0x69b9[24])[_0x69b9[23]]();
                    $(_0x69b9[29] + _0xe8e3x2[_0x69b9[21]] + _0x69b9[30])[_0x69b9[13]]({
                        width: _0x69b9[25]
                    }, {
                        queue: false,
                        duration: _0xe8e3x2[_0x69b9[26]],
                        easing: _0x69b9[12]
                    });
                };
                _0xe8e3x5[_0x69b9[31]]();
            });
            $(_0x69b9[10])[_0x69b9[14]](_0x69b9[16], function() {
                if ($(_0x69b9[3])[_0x69b9[18]](_0x69b9[17])) {
                    return;
                };
                if (_0xe8e3x2[_0x69b9[21]] <= 0) {
                    _0xe8e3x2[_0x69b9[21]] = $(_0x69b9[3])[_0x69b9[32]]();
                    $(_0x69b9[24])[_0x69b9[23]]();
                    $(_0x69b9[24])[_0x69b9[4]]({
                        width: _0x69b9[25]
                    });
                    $(_0x69b9[28])[_0x69b9[13]]({
                        width: _0x69b9[27]
                    }, {
                        queue: false,
                        duration: _0xe8e3x2[_0x69b9[26]],
                        easing: _0x69b9[12]
                    });
                } else {
                    _0xe8e3x2[_0x69b9[21]]--;
                    $(_0x69b9[24])[_0x69b9[23]]();
                    $(_0x69b9[33] + _0xe8e3x2[_0x69b9[21]] + _0x69b9[30])[_0x69b9[4]]({
                        width: _0x69b9[27]
                    });
                    $(_0x69b9[34] + _0xe8e3x2[_0x69b9[21]] + _0x69b9[30])[_0x69b9[13]]({
                        width: _0x69b9[27]
                    }, {
                        queue: false,
                        duration: _0xe8e3x2[_0x69b9[26]],
                        easing: _0x69b9[12]
                    });
                };
                _0xe8e3x5[_0x69b9[31]]();
            });
        }
    };
    var _0xe8e3x5 = {
        init: function() {
            for (var _0xe8e3x6 = 0; _0xe8e3x6 < $(_0x69b9[3])[_0x69b9[19]]; _0xe8e3x6++) {
                $(_0x69b9[37])[_0x69b9[36]](_0x69b9[35]);
            };
            $(_0x69b9[35])[_0x69b9[4]]({
                width: ($(_0x69b9[38])[_0x69b9[19]] + 1) * 45
            });
            $(_0x69b9[20] + _0xe8e3x2[_0x69b9[21]] + _0x69b9[22])[_0x69b9[40]]({
                duration: 500,
                easing: _0x69b9[39]
            });
            $(_0x69b9[5])[_0x69b9[13]]({
                height: $(_0x69b9[41])[_0x69b9[2]]()
            }, {
                queue: false,
                duration: 500,
                easing: _0x69b9[42],
                complete: function() {
                    $(_0x69b9[10])[_0x69b9[13]]({
                        left: 0
                    }, {
                        queue: false,
                        duration: 1000,
                        easing: _0x69b9[12]
                    });
                    $(_0x69b9[8])[_0x69b9[13]]({
                        right: 0
                    }, {
                        queue: false,
                        duration: 1000,
                        easing: _0x69b9[12]
                    });
                    _0xe8e3x5[_0x69b9[43]]();
                    _0xe8e3x4[_0x69b9[6]]();
                    _0xe8e3x3[_0x69b9[7]]();
                    _0xe8e3x7[_0x69b9[44]]();
                    _0xe8e3x7[_0x69b9[45]]();
                }
            });
        },
        show: function() {
            _0xe8e3x5[_0x69b9[46]]();
            $(_0x69b9[20] + _0xe8e3x2[_0x69b9[21]] + _0x69b9[22])[_0x69b9[4]]({
                opacity: 0,
                zIndex: 2
            })[_0x69b9[31]]()[_0x69b9[13]]({
                opacity: 1
            }, {
                queue: false,
                duration: _0xe8e3x2[_0x69b9[26]],
                easing: _0x69b9[39],
                complete: function() {
                    $(_0x69b9[48] + _0xe8e3x2[_0x69b9[21]] + _0x69b9[49] + _0xe8e3x2[_0x69b9[21]] + _0x69b9[22])[_0x69b9[4]]({
                        zIndex: 0
                    })[_0x69b9[47]]();
                    $(_0x69b9[20] + _0xe8e3x2[_0x69b9[21]] + _0x69b9[22])[_0x69b9[4]]({
                        zIndex: 1
                    });
                    _0xe8e3x5[_0x69b9[43]]();
                    _0xe8e3x7[_0x69b9[44]]();
                }
            });
        },
        showText: function() {
            $(_0x69b9[20] + _0xe8e3x2[_0x69b9[21]] + _0x69b9[50])[_0x69b9[13]]({
                opacity: 1
            }, {
                queue: false,
                duration: 300,
                easing: _0x69b9[39]
            });
            setTimeout(function() {
                $(_0x69b9[20] + _0xe8e3x2[_0x69b9[21]] + _0x69b9[51])[_0x69b9[13]]({
                    opacity: 1
                }, {
                    queue: false,
                    duration: 300,
                    easing: _0x69b9[39]
                });
            }, 150);
            setTimeout(function() {
                $(_0x69b9[20] + _0xe8e3x2[_0x69b9[21]] + _0x69b9[52])[_0x69b9[13]]({
                    opacity: 1
                }, {
                    queue: false,
                    duration: 300,
                    easing: _0x69b9[39]
                });
            }, 300);
        },
        hideText: function() {
            $(_0x69b9[53])[_0x69b9[13]]({
                opacity: 0
            }, {
                queue: false,
                duration: 300,
                easing: _0x69b9[39]
            });
            setTimeout(function() {
                $(_0x69b9[54])[_0x69b9[13]]({
                    opacity: 0
                }, {
                    queue: false,
                    duration: 300,
                    easing: _0x69b9[39]
                });
            }, 150);
            setTimeout(function() {
                $(_0x69b9[55])[_0x69b9[13]]({
                    opacity: 0
                }, {
                    queue: false,
                    duration: 300,
                    easing: _0x69b9[39]
                });
            }, 300);
        }
    };
    var _0xe8e3x7 = {
        run: function() {
            $(_0x69b9[58] + _0xe8e3x2[_0x69b9[21]] + _0x69b9[30])[_0x69b9[13]]({
                width: _0x69b9[25]
            }, {
                queue: false,
                duration: (_0xe8e3x2[_0x69b9[56]] - (_0xe8e3x2[_0x69b9[56]] / 100) * ((($(_0x69b9[58] + _0xe8e3x2[_0x69b9[21]] + _0x69b9[30])[_0x69b9[57]]() / $(_0x69b9[58] + _0xe8e3x2[_0x69b9[21]] + _0x69b9[22])[_0x69b9[57]]()) * 100))),
                easing: _0x69b9[59],
                complete: function() {
                    $(_0x69b9[8])[_0x69b9[60]](_0x69b9[16]);
                }
            });
        },
        focus: function() {
            $(_0x69b9[62])[_0x69b9[14]](_0x69b9[11], function() {
                if ($(_0x69b9[3])[_0x69b9[18]](_0x69b9[17])) {
                    return;
                };
                $(_0x69b9[61])[_0x69b9[23]]();
            });
            $(_0x69b9[62])[_0x69b9[14]](_0x69b9[63], function() {
                if ($(_0x69b9[3])[_0x69b9[18]](_0x69b9[17])) {
                    return;
                };
                _0xe8e3x7[_0x69b9[44]]();
            });
        }
    };
};

$(window)[_0x69b9[64]](function() {
    new mainSlider()[_0x69b9[0]]();
});
})(jQuery);