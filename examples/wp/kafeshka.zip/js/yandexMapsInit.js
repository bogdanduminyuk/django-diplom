function yandexMapsInit () {
	var myMap = new ymaps.Map("map", {
			center: [55.906815, 37.400478],
			zoom: 16
		}, {
		        searchControlProvider: 'yandex#search'
		}),
			// Создаем геообъект с типом геометрии "Точка".
			myGeoObject = new ymaps.GeoObject({
			    // Описание геометрии.
			   		geometry: {
			   		type: "Point",
			       	coordinates: [55.906815, 37.400478]
			},
			    // Свойства.
			   	properties: {
			       	// Контент метки.
			        	hintContent: 'General\'s Home'
			   	}
			}, {
				// Опции.
				// Иконка метки будет растягиваться под размер ее содержимого.
					preset: 'islands#icon',
				// Метку можно перемещать.
					draggable: false,
					iconColor: '#0095b6'
			});
				
			myMap.geoObjects.add(myGeoObject)
						    .add(new ymaps.Placemark([55.906815, 37.400478], {
			        balloonContent: 'цвет <strong>воды пляжа бонди</strong>'
			    }, {
				        preset: 'islands#icon',
				        iconColor: '#0095b6'
			}));
}